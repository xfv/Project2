# Project2: panorama
Report:
    http://2015digivfx.weebly.com
Usage:
    python main.py

Result is named 'pano_linear.jpg', and 'pano_poisson.jpg'
